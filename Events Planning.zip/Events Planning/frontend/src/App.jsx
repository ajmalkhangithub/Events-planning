import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Herosection from './components/Herosection';
import About from './components/About';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import NewsHeading from './components/NewsHeading';
import './App.css'
function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Herosection />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
      <Footer/>
      <NewsHeading/>
    </Router>

  );
}
export default App;