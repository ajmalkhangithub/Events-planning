import React from 'react'

const About = () => {
  return (
    <div>
      <h1>About</h1>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam, explicabo assumenda beatae voluptatem tenetur cumque placeat delectus laboriosam provident aliquid expedita inventore aspernatur id vitae eveniet, soluta, saepe perspiciatis consectetur distinctio iure exercitationem dolores dolor sed? Vitae totam dolorum id ut, eius quia eos inventore illo expedita asperiores maxime tempora!</p>
    </div>
  )
}

export default About
