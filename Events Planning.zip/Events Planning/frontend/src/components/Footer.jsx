import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
      <h1>Footer</h1>
    </div>
  )
}

export default Footer
