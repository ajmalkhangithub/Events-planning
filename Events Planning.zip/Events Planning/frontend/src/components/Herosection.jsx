import React from 'react';
import { NavLink } from 'react-router-dom';


export const Herosection = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Make Your Event Unforgettable</h1>
        <p>Your dream event is just a click away. Let us handle everything!</p>
        <NavLink to="/contact" className="hero-btn">Book Now</NavLink>
      </div>
    </section>
  );
};

export default Herosection;


