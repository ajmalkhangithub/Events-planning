import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';


const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">EVENT PLANNER</div>

      <div className="hamburger" onClick={toggleMenu}>
        <span className={isOpen ? 'bar open' : 'bar'}></span>
        <span className={isOpen ? 'bar open' : 'bar'}></span>
        <span className={isOpen ? 'bar open' : 'bar'}></span>
      </div>

      <ul className={`navbar-links ${isOpen ? 'active' : ''}`}>
        <li><NavLink to="/" exact="true" activeclassname="active" onClick={toggleMenu}>Home</NavLink></li>
        <li><NavLink to="/about" activeclassname="active" onClick={toggleMenu}>About</NavLink></li>
        <li><NavLink to="/services" activeclassname="active" onClick={toggleMenu}>Services</NavLink></li>
        <li><NavLink to="/contact" activeclassname="active" onClick={toggleMenu}>Contact</NavLink></li>
      </ul>
    </nav>
  );
};

export default Navbar;
