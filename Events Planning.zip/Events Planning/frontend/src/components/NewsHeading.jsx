import React, { useState, useEffect } from "react";
import axios from "axios";

const NewsHeading = () => {
  const [mydata, setData] = useState([]);

  const getData = async () => {
    try {
      const res = await axios.get("https://newsapi.org/v2/top-headlines?country=us&apiKey=24cfb585c8b246669f42fe97ae36346d");

      setData(res.data.articles);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <div>
      <h2>News Headlines</h2>
      {mydata.map((article, index) => (
        <div key={index}>
          <h3>{article.title}</h3>
          <p>{article.description}</p>
        </div>
      ))}
      {mydata.map((value,index)=>(
        <div key={index}>
<h3>{value.title}</h3>

        </div>
      ))}
    </div>
  );
};

export default NewsHeading;
